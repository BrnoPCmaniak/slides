# -*- coding: utf-8 -*-
from PyQt4.QtCore import QSize
from PyQt4.QtCore import SIGNAL
from PyQt4.QtGui import QColorDialog
from PyQt4.QtGui import QImage
from PyQt4.QtGui import QLabel
from PyQt4.QtGui import QPixmap
from PyQt4.QtGui import QPushButton
from PyQt4.QtGui import QVBoxLayout
from qgis._core import QGis
from qgis._core import QgsStyleV2
from qgis._core import QgsSymbolLayerV2Utils
from qgis._core import QgsSymbolV2
from qgis._gui import QgsColorButtonV2
from qgis._gui import QgsDataDefinedSymbolDialog
from qgis._gui import QgsRendererV2Widget
from qgis._gui import QgsSingleSymbolRendererV2Widget
from qgis._gui import QgsSymbolV2SelectorDialog

from CustomRenderer import CustomRenderer


class CustomRendererWidget(QgsRendererV2Widget):
    def __init__(self, layer, style, renderer):
        QgsRendererV2Widget.__init__(self, layer, style)
        if renderer is None or renderer.type() != "CustomRenderer":
            self.r = CustomRenderer()
        else:
            self.r = renderer

        # setup UI
        self.btn1 = QgsColorButtonV2()

        #(QgsSymbolV2, QgsStyleV2, QgsVectorLayer, QWidget_parent=None, bool_embedded=False)
        self.symbol = QgsSymbolV2SelectorDialog(
            self.r.syms[0], #Symbol
            style,
            layer,  # QgsVectorLayer
            self,  # Parent
            False  # Embedded
        )

        self.button = QPushButton()
        #icon = QgsSymbolLayerV2Utils.symbolPreviewIcon(self.r.syms[0], QSize(10, 10))
        icon = QgsSymbolLayerV2Utils.symbolPreviewIcon(self.r.syms[0], QSize(10, 10))
        self.button.setIcon(icon)

        self.label = QLabel()
        #pixmap = QgsSymbolLayerV2Utils.symbolPreviewPixmap(self.r.syms[0], QSize(20, 20))
        #self.label.setPixmap(pixmap)

        preview = self.r.syms[0].bigSymbolPreviewImage()
        self.label.setPixmap(QPixmap.fromImage(preview))


        self.connect(self.button, SIGNAL("clicked()"), self.symbol.show)

        self.btn1.setColor(self.r.syms[0].color())
        self.vbox = QVBoxLayout()
        self.vbox.addWidget(self.btn1)
        self.vbox.addWidget(self.button)
        self.vbox.addWidget(self.label)
        self.setLayout(self.vbox)

        self.connect(self.btn1, SIGNAL("colorChanged(QColor)"), self.setColor1)

    def setColor1(self, color):
        if not color.isValid():
            return
        self.r.syms[0].setColor(color)

    def renderer(self):
        return self.r
