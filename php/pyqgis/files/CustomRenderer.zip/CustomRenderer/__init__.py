# -*- coding: utf-8 -*-


def classFactory(iface):
    """Load SaveAttributes class from file SaveAttributes.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    from .CustomRendererPlugin import Plugin
    return Plugin(iface)
