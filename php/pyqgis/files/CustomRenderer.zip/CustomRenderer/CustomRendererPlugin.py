# -*- coding: utf-8 -*-
import os
from qgis.core import QgsRendererV2Registry
from CustomRendererMetadata import CustomRendererMetadata


class Plugin:
    def __init__(self, iface):
        self._iface = iface
        self._plugin_dir = os.path.dirname(__file__)
        self._metadata = None

    def initGui(self):
        self._metadata = CustomRendererMetadata()
        QgsRendererV2Registry.instance().addRenderer(self._metadata)

    def unload(self):
        QgsRendererV2Registry.instance().removeRenderer("CustomRenderer")

    def canBeUninstalled(self):
        return True

