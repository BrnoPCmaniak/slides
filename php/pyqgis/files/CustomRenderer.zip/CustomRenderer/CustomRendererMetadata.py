# -*- coding: utf-8 -*-

from qgis._core import QgsRendererV2AbstractMetadata

from CustomRenderer import CustomRenderer
from CustomRendererWidget import CustomRendererWidget


class CustomRendererMetadata(QgsRendererV2AbstractMetadata):
    def __init__(self):
        QgsRendererV2AbstractMetadata.__init__(self, "CustomRenderer", "Custom renderer")

    def createRenderer(self, element):
        return CustomRenderer()

    def createRendererWidget(self, layer, style, renderer):
        return CustomRendererWidget(layer, style, renderer)
