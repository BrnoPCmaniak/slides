# -*- coding: utf-8 -*-


def classFactory(iface):
    from mainPlugin import Plugin
    return Plugin(iface)
