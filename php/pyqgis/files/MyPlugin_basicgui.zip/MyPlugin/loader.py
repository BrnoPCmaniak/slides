# -*- coding: utf-8 -*-

from os import path
from glob import glob


class Loader:
    def __init__(self, iface):
        self._iface = iface

    def load(self, folder):
        for shp in glob(path.join(folder, "*.shp")):
            self._iface.addVectorLayer(shp, path.basename(shp), 'ogr')

