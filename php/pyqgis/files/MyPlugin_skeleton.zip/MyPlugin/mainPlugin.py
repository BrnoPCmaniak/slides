# -*- coding: utf-8 -*-


class Plugin:
    def __init__(self, iface):
        # This method is called on initialization of plugin ("The first method")
        self._iface = iface
        print "Initialiting My Plugin"

    def initGui(self):
        # This method is called when the plugin is loaded
        print "Loading My Plugin"

    def unload(self):
        # This method is called when the plugin is
        print "Unloading My Plugin"
